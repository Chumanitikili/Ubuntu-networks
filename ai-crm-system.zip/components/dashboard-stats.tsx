import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, Phone, Target, Clock, CheckCircle } from "lucide-react"

const stats = [
  {
    title: "Active Calls",
    value: "12",
    change: "+3",
    trend: "up",
    icon: Phone,
    description: "Currently in progress",
    color: "from-green-500 to-emerald-500",
  },
  {
    title: "Calls Today",
    value: "247",
    change: "+18%",
    trend: "up",
    icon: CheckCircle,
    description: "vs yesterday",
    color: "from-blue-500 to-cyan-500",
  },
  {
    title: "Avg Response Time",
    value: "1.2s",
    change: "-0.3s",
    trend: "up",
    icon: Clock,
    description: "AI response speed",
    color: "from-purple-500 to-pink-500",
  },
  {
    title: "Resolution Rate",
    value: "94%",
    change: "+5%",
    trend: "up",
    icon: Target,
    description: "First call resolution",
    color: "from-orange-500 to-red-500",
  },
]

export function DashboardStats() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card
          key={stat.title}
          className="bg-slate-800/50 border-slate-700 backdrop-blur-sm hover:bg-slate-800/70 transition-all duration-200"
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-300">{stat.title}</CardTitle>
            <div className={`p-2 rounded-lg bg-gradient-to-br ${stat.color}`}>
              <stat.icon className="h-4 w-4 text-white" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stat.value}</div>
            <div className="flex items-center justify-between mt-1">
              <div className="flex items-center text-xs">
                {stat.trend === "up" ? (
                  <TrendingUp className="mr-1 h-3 w-3 text-green-400" />
                ) : (
                  <TrendingDown className="mr-1 h-3 w-3 text-red-400" />
                )}
                <span className={stat.trend === "up" ? "text-green-400" : "text-red-400"}>{stat.change}</span>
              </div>
              <span className="text-xs text-slate-400">{stat.description}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
