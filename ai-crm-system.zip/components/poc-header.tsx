import { Bell, Search, Settings, Star } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { SidebarTrigger } from "@/components/ui/sidebar"

export function POCHeader() {
  return (
    <header className="sticky top-0 z-50 flex h-16 shrink-0 items-center gap-2 border-b border-white/10 bg-slate-900/80 backdrop-blur-md px-6">
      <SidebarTrigger className="-ml-1 text-blue-300 hover:bg-blue-500/20" />
      <div className="flex flex-1 items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent font-ubuntu">
            Trial Dashboard
          </h1>
          <Badge variant="secondary" className="bg-blue-500/20 text-blue-300 border-blue-400/30">
            67 days remaining
          </Badge>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search features..."
              className="pl-10 w-80 bg-slate-800/50 border-slate-700 text-slate-200 placeholder:text-slate-400 focus:border-blue-400"
            />
          </div>
          <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600">
            <Star className="mr-2 h-4 w-4" />
            Upgrade Trial
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="border-slate-700 bg-slate-800/50 hover:bg-blue-500/20 text-slate-300"
          >
            <Bell className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="border-slate-700 bg-slate-800/50 hover:bg-blue-500/20 text-slate-300"
          >
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  )
}
