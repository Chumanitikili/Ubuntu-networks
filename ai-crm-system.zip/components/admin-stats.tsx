import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, Users, Building2, Clock, DollarSign } from "lucide-react"

const stats = [
  {
    title: "Total Users",
    value: "12,847",
    change: "+12.5%",
    trend: "up",
    icon: Users,
    description: "Active across all companies",
    color: "from-blue-500 to-cyan-500",
  },
  {
    title: "Active Companies",
    value: "156",
    change: "+8.2%",
    trend: "up",
    icon: Building2,
    description: "Paying customers",
    color: "from-green-500 to-emerald-500",
  },
  {
    title: "POC Accounts",
    value: "23",
    change: "+15.1%",
    trend: "up",
    icon: Clock,
    description: "90-day trials active",
    color: "from-orange-500 to-red-500",
  },
  {
    title: "Monthly Revenue",
    value: "$245,231",
    change: "+23.1%",
    trend: "up",
    icon: DollarSign,
    description: "Recurring revenue",
    color: "from-purple-500 to-pink-500",
  },
]

export function AdminStats() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card
          key={stat.title}
          className="bg-slate-800/50 border-slate-700 backdrop-blur-sm hover:bg-slate-800/70 transition-all duration-200"
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-300">{stat.title}</CardTitle>
            <div className={`p-2 rounded-lg bg-gradient-to-br ${stat.color}`}>
              <stat.icon className="h-4 w-4 text-white" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stat.value}</div>
            <div className="flex items-center justify-between mt-1">
              <div className="flex items-center text-xs">
                {stat.trend === "up" ? (
                  <TrendingUp className="mr-1 h-3 w-3 text-green-400" />
                ) : (
                  <TrendingDown className="mr-1 h-3 w-3 text-red-400" />
                )}
                <span className={stat.trend === "up" ? "text-green-400" : "text-red-400"}>{stat.change}</span>
              </div>
              <span className="text-xs text-slate-400">{stat.description}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
