import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { TrendingUp, TrendingDown, Phone, Users, MessageSquare, Target } from "lucide-react"

const stats = [
  {
    title: "Calls Handled",
    value: "247",
    change: "+18%",
    trend: "up",
    icon: Phone,
    description: "AI-powered calls",
    color: "from-blue-500 to-cyan-500",
  },
  {
    title: "Contacts Added",
    value: "89",
    change: "+12%",
    trend: "up",
    icon: Users,
    description: "New leads captured",
    color: "from-green-500 to-emerald-500",
  },
  {
    title: "AI Interactions",
    value: "1,234",
    change: "+25%",
    trend: "up",
    icon: MessageSquare,
    description: "Automated responses",
    color: "from-purple-500 to-pink-500",
  },
  {
    title: "Conversion Rate",
    value: "16.8%",
    change: "+3.2%",
    trend: "up",
    icon: Target,
    description: "Lead to customer",
    color: "from-orange-500 to-red-500",
  },
]

export function POCStats() {
  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {stats.map((stat) => (
        <Card
          key={stat.title}
          className="bg-slate-800/50 border-slate-700 backdrop-blur-sm hover:bg-slate-800/70 transition-all duration-200"
        >
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-slate-300">{stat.title}</CardTitle>
            <div className={`p-2 rounded-lg bg-gradient-to-br ${stat.color}`}>
              <stat.icon className="h-4 w-4 text-white" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-white">{stat.value}</div>
            <div className="flex items-center justify-between mt-1">
              <div className="flex items-center text-xs">
                {stat.trend === "up" ? (
                  <TrendingUp className="mr-1 h-3 w-3 text-green-400" />
                ) : (
                  <TrendingDown className="mr-1 h-3 w-3 text-red-400" />
                )}
                <span className={stat.trend === "up" ? "text-green-400" : "text-red-400"}>{stat.change}</span>
              </div>
              <span className="text-xs text-slate-400">{stat.description}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  )
}
