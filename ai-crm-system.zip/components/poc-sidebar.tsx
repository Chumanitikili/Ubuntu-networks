"use client"
import {
  Network,
  Clock,
  BarChart3,
  Phone,
  Users,
  MessageSquare,
  Calendar,
  HelpCircle,
  ChevronUp,
  Star,
} from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

const pocNavigation = [
  {
    title: "Trial Dashboard",
    url: "/poc",
    icon: BarChart3,
    isActive: true,
  },
  {
    title: "Live Calls",
    url: "/poc/calls",
    icon: Phone,
  },
  {
    title: "AI Assistant",
    url: "/poc/ai",
    icon: MessageSquare,
  },
  {
    title: "Contacts",
    url: "/poc/contacts",
    icon: Users,
  },
  {
    title: "Calendar",
    url: "/poc/calendar",
    icon: Calendar,
  },
  {
    title: "Support",
    url: "/poc/support",
    icon: HelpCircle,
  },
]

export function POCSidebar() {
  return (
    <Sidebar variant="inset" className="border-r border-white/10">
      <SidebarHeader className="border-b border-white/10 bg-gradient-to-r from-blue-600/20 to-cyan-600/20">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" asChild>
              <a href="/poc" className="group">
                <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 text-white shadow-lg">
                  <Network className="size-4" />
                </div>
                <div className="grid flex-1 text-left text-sm leading-tight">
                  <span className="truncate font-semibold text-white font-ubuntu">Ubuntu Networks</span>
                  <span className="truncate text-xs text-blue-200">90-Day Trial</span>
                </div>
                <Badge variant="secondary" className="bg-blue-500/20 text-blue-200 border-blue-400/30">
                  <Clock className="h-3 w-3 mr-1" />
                  POC
                </Badge>
              </a>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>
      <SidebarContent className="bg-slate-900/50 backdrop-blur-sm">
        <SidebarGroup>
          <SidebarGroupLabel className="text-blue-200 font-medium">Trial Features</SidebarGroupLabel>
          <SidebarMenu>
            {pocNavigation.map((item) => (
              <SidebarMenuItem key={item.title}>
                <SidebarMenuButton
                  asChild
                  isActive={item.isActive}
                  className="group hover:bg-blue-500/10 data-[active=true]:bg-blue-500/20 data-[active=true]:text-blue-200"
                >
                  <a href={item.url} className="flex items-center gap-2 w-full">
                    <item.icon className="text-blue-300" />
                    <span className="text-slate-200">{item.title}</span>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="border-t border-white/10 bg-gradient-to-r from-blue-600/10 to-cyan-600/10">
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <SidebarMenuButton size="lg" className="data-[state=open]:bg-blue-500/20 hover:bg-blue-500/10">
                  <Avatar className="h-8 w-8 rounded-lg border-2 border-blue-400/30">
                    <AvatarImage src="/placeholder.svg" alt="Trial User" />
                    <AvatarFallback className="rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 text-white">
                      TU
                    </AvatarFallback>
                  </Avatar>
                  <div className="grid flex-1 text-left text-sm leading-tight">
                    <span className="truncate font-semibold text-white">Trial User</span>
                    <span className="truncate text-xs text-blue-200">trial@company.com</span>
                  </div>
                  <ChevronUp className="ml-auto size-4 text-blue-300" />
                </SidebarMenuButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                className="w-[--radix-dropdown-menu-trigger-width] min-w-56 rounded-lg bg-slate-800 border-slate-700"
                side="bottom"
                align="end"
                sideOffset={4}
              >
                <DropdownMenuItem className="hover:bg-blue-500/20 text-slate-200">
                  <Star className="mr-2 h-4 w-4" />
                  Upgrade to Full
                </DropdownMenuItem>
                <DropdownMenuItem className="hover:bg-blue-500/20 text-slate-200">
                  <HelpCircle className="mr-2 h-4 w-4" />
                  Trial Support
                </DropdownMenuItem>
                <DropdownMenuItem className="hover:bg-red-500/20 text-red-300">Sign out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  )
}
