import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Users, Plus, UserCheck, UserX } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const recentUsers = [
  {
    id: 1,
    name: "John Smith",
    email: "john@techcorp.com",
    company: "TechCorp Inc",
    role: "company_admin",
    status: "active",
    joinedAt: "2 hours ago",
  },
  {
    id: 2,
    name: "Sarah Johnson",
    email: "sarah@startup.io",
    company: "Startup.io",
    role: "poc_user",
    status: "trial",
    joinedAt: "1 day ago",
  },
  {
    id: 3,
    name: "Mike Davis",
    email: "mike@enterprise.com",
    company: "Enterprise Corp",
    role: "user",
    status: "active",
    joinedAt: "3 days ago",
  },
]

const getRoleColor = (role: string) => {
  switch (role) {
    case "admin":
      return "bg-red-500/20 text-red-300 border-red-400/30"
    case "superuser":
      return "bg-purple-500/20 text-purple-300 border-purple-400/30"
    case "company_admin":
      return "bg-blue-500/20 text-blue-300 border-blue-400/30"
    case "poc_user":
      return "bg-orange-500/20 text-orange-300 border-orange-400/30"
    default:
      return "bg-slate-500/20 text-slate-300 border-slate-400/30"
  }
}

const getStatusColor = (status: string) => {
  switch (status) {
    case "active":
      return "bg-green-500/20 text-green-300 border-green-400/30"
    case "trial":
      return "bg-yellow-500/20 text-yellow-300 border-yellow-400/30"
    case "inactive":
      return "bg-red-500/20 text-red-300 border-red-400/30"
    default:
      return "bg-slate-500/20 text-slate-300 border-slate-400/30"
  }
}

export function UserManagement() {
  return (
    <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-white flex items-center gap-2">
              <Users className="h-5 w-5 text-blue-400" />
              User Management
            </CardTitle>
            <CardDescription className="text-slate-400">Recent user activity and management</CardDescription>
          </div>
          <Button
            size="sm"
            className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600"
          >
            <Plus className="h-4 w-4 mr-1" />
            Add User
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {recentUsers.map((user) => (
          <div
            key={user.id}
            className="flex items-center justify-between p-3 rounded-lg bg-slate-900/50 border border-slate-700 hover:bg-slate-900/70 transition-all duration-200"
          >
            <div className="flex items-center gap-3">
              <Avatar className="h-10 w-10 border-2 border-orange-400/30">
                <AvatarImage src="/placeholder.svg" alt={user.name} />
                <AvatarFallback className="bg-gradient-to-br from-orange-500 to-red-500 text-white">
                  {user.name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div className="space-y-1">
                <h3 className="font-medium text-white">{user.name}</h3>
                <div className="flex items-center gap-2 text-sm text-slate-400">
                  <span>{user.email}</span>
                  <span>•</span>
                  <span>{user.company}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className={getRoleColor(user.role)}>
                    {user.role.replace("_", " ")}
                  </Badge>
                  <Badge variant="outline" className={getStatusColor(user.status)}>
                    {user.status}
                  </Badge>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <div className="text-right">
                <div className="text-xs text-slate-400">{user.joinedAt}</div>
              </div>
              <div className="flex gap-1">
                <Button variant="outline" size="sm" className="border-slate-600 bg-slate-800 hover:bg-green-500/20">
                  <UserCheck className="h-4 w-4" />
                </Button>
                <Button variant="outline" size="sm" className="border-slate-600 bg-slate-800 hover:bg-red-500/20">
                  <UserX className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </div>
        ))}

        <div className="pt-4 border-t border-slate-700">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-lg font-bold text-blue-400">12,847</div>
              <div className="text-xs text-slate-400">Total Users</div>
            </div>
            <div>
              <div className="text-lg font-bold text-orange-400">23</div>
              <div className="text-xs text-slate-400">POC Trials</div>
            </div>
            <div>
              <div className="text-lg font-bold text-green-400">156</div>
              <div className="text-xs text-slate-400">Companies</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
