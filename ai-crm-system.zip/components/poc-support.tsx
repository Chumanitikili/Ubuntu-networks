import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { HelpCircle, MessageCircle, Phone, Mail, BookOpen, Video, Clock, Star } from "lucide-react"

const supportOptions = [
  {
    title: "Live Chat Support",
    description: "Get instant help from our support team",
    icon: MessageCircle,
    availability: "24/7",
    responseTime: "< 5 minutes",
    action: "Start Chat",
  },
  {
    title: "Phone Support",
    description: "Speak directly with a technical expert",
    icon: Phone,
    availability: "Business Hours",
    responseTime: "Immediate",
    action: "Call Now",
  },
  {
    title: "Email Support",
    description: "Send detailed questions and get comprehensive answers",
    icon: Mail,
    availability: "24/7",
    responseTime: "< 2 hours",
    action: "Send Email",
  },
  {
    title: "Video Training",
    description: "Watch guided tutorials and best practices",
    icon: Video,
    availability: "On-demand",
    responseTime: "Self-paced",
    action: "Watch Now",
  },
]

const resources = [
  {
    title: "Getting Started Guide",
    description: "Complete setup and configuration walkthrough",
    icon: BookOpen,
    type: "Documentation",
  },
  {
    title: "API Documentation",
    description: "Technical integration guides and examples",
    icon: BookOpen,
    type: "Technical",
  },
  {
    title: "Best Practices",
    description: "Optimize your call center performance",
    icon: Star,
    type: "Guide",
  },
]

export function POCSupport() {
  return (
    <div className="space-y-6">
      <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <HelpCircle className="h-5 w-5 text-blue-400" />
            Trial Support
          </CardTitle>
          <CardDescription className="text-slate-400">Get help during your 90-day evaluation period</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {supportOptions.map((option) => (
            <div
              key={option.title}
              className="p-3 rounded-lg bg-slate-900/50 border border-slate-700 hover:bg-slate-900/70 transition-all duration-200"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <option.icon className="h-4 w-4 text-blue-400" />
                  <h4 className="font-medium text-white text-sm">{option.title}</h4>
                </div>
                <Badge variant="outline" className="bg-blue-500/20 text-blue-300 border-blue-400/30 text-xs">
                  {option.availability}
                </Badge>
              </div>
              <p className="text-xs text-slate-400 mb-2">{option.description}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1 text-xs text-slate-500">
                  <Clock className="h-3 w-3" />
                  {option.responseTime}
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="border-blue-400/30 bg-blue-500/10 hover:bg-blue-500/20 text-blue-300 text-xs h-7"
                >
                  {option.action}
                </Button>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <BookOpen className="h-5 w-5 text-green-400" />
            Resources
          </CardTitle>
          <CardDescription className="text-slate-400">Documentation and learning materials</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          {resources.map((resource) => (
            <div
              key={resource.title}
              className="p-3 rounded-lg bg-slate-900/50 border border-slate-700 hover:bg-slate-900/70 transition-all duration-200 cursor-pointer"
            >
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <resource.icon className="h-4 w-4 text-green-400" />
                  <div>
                    <h4 className="font-medium text-white text-sm">{resource.title}</h4>
                    <p className="text-xs text-slate-400">{resource.description}</p>
                  </div>
                </div>
                <Badge variant="outline" className="bg-green-500/20 text-green-300 border-green-400/30 text-xs">
                  {resource.type}
                </Badge>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
