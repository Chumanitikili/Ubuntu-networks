import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, Zap, Phone, Calendar, MessageSquare, Users, Settings } from "lucide-react"

const actions = [
  {
    title: "Start AI Call",
    description: "Initiate AI-powered call",
    icon: Phone,
    variant: "default" as const,
    color: "from-green-500 to-emerald-500",
  },
  {
    title: "New Campaign",
    description: "Create engagement campaign",
    icon: Plus,
    variant: "outline" as const,
    color: "from-purple-500 to-pink-500",
  },
  {
    title: "Schedule Follow-up",
    description: "Auto-schedule callback",
    icon: Calendar,
    variant: "outline" as const,
    color: "from-blue-500 to-cyan-500",
  },
  {
    title: "Send SMS",
    description: "Quick SMS broadcast",
    icon: MessageSquare,
    variant: "outline" as const,
    color: "from-orange-500 to-red-500",
  },
  {
    title: "Add Contact",
    description: "Import new lead",
    icon: Users,
    variant: "outline" as const,
    color: "from-indigo-500 to-purple-500",
  },
  {
    title: "AI Training",
    description: "Optimize AI responses",
    icon: Settings,
    variant: "outline" as const,
    color: "from-pink-500 to-rose-500",
  },
]

export function QuickActions() {
  return (
    <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-white flex items-center gap-2">
          <Zap className="h-5 w-5 text-yellow-400" />
          Quick Actions
        </CardTitle>
        <CardDescription className="text-slate-400">AI-powered shortcuts and automations</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        {actions.map((action) => (
          <Button
            key={action.title}
            variant={action.variant}
            className={`w-full justify-start h-auto p-3 ${
              action.variant === "default"
                ? `bg-gradient-to-r ${action.color} hover:opacity-90 text-white border-0`
                : "border-slate-600 bg-slate-800/50 hover:bg-slate-700/50 text-slate-200"
            }`}
          >
            <div
              className={`p-2 rounded-lg mr-3 ${
                action.variant === "default" ? "bg-white/20" : `bg-gradient-to-br ${action.color}`
              }`}
            >
              <action.icon className="h-4 w-4 text-white" />
            </div>
            <div className="text-left">
              <div className="font-medium">{action.title}</div>
              <div className="text-xs opacity-70">{action.description}</div>
            </div>
          </Button>
        ))}
      </CardContent>
    </Card>
  )
}
