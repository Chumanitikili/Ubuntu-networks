"use client"
import {
  Bot,
  Calendar,
  ChevronUp,
  Home,
  Settings,
  TrendingUp,
  Users,
  BarChart3,
  BookOpen,
  Target,
  Star,
  Workflow,
  HeadphonesIcon,
  BrainCircuit,
  Megaphone,
  GraduationCap,
  HelpCircle,
  Clock,
  Phone,
  Zap,
} from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarMenuSub,
  SidebarMenuSubButton,
  SidebarMenuSubItem,
} from "@/components/ui/sidebar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { Badge } from "@/components/ui/badge"

const data = {
  user: {
    name: "Sarah Johnson",
    email: "sarah@company.com",
    avatar: "/placeholder.svg?height=32&width=32",
    role: "Call Center Manager",
  },
  navMain: [
    {
      title: "Dashboard",
      url: "/",
      icon: Home,
      isActive: true,
    },
    {
      title: "Live Calls",
      url: "/calls",
      icon: Phone,
      badge: "3",
    },
    {
      title: "AI Assistant",
      icon: BrainCircuit,
      items: [
        {
          title: "AI Receptionist",
          url: "/ai/receptionist",
          icon: HeadphonesIcon,
          description: "Intelligent call handling",
        },
        {
          title: "Call Analytics",
          url: "/ai/analytics",
          icon: BarChart3,
          description: "Performance insights",
        },
        {
          title: "Voice Training",
          url: "/ai/training",
          icon: GraduationCap,
          description: "AI voice optimization",
        },
      ],
    },
    {
      title: "Campaigns",
      icon: Megaphone,
      items: [
        {
          title: "Re-engagement",
          url: "/campaigns/reengagement",
          icon: TrendingUp,
          description: "Win back customers",
        },
        {
          title: "Lead Nurturing",
          url: "/campaigns/nurturing",
          icon: Target,
          description: "Convert prospects",
        },
        {
          title: "Reviews & Referrals",
          url: "/campaigns/reviews",
          icon: Star,
          description: "Build reputation",
        },
      ],
    },
    {
      title: "Automation",
      icon: Workflow,
      items: [
        {
          title: "Workflows",
          url: "/automation/workflows",
          icon: Zap,
          description: "Custom automations",
        },
        {
          title: "Scheduling",
          url: "/automation/scheduling",
          icon: Calendar,
          description: "Smart booking",
        },
        {
          title: "Follow-ups",
          url: "/automation/followups",
          icon: Clock,
          description: "Automated sequences",
        },
      ],
    },
    {
      title: "Contacts",
      url: "/contacts",
      icon: Users,
    },
    {
      title: "Analytics",
      url: "/analytics",
      icon: BarChart3,
    },
    {
      title: "Knowledge Base",
      url: "/knowledge",
      icon: BookOpen,
    },
  ],
}

export function AppSidebar() {
  return (
    <Sidebar variant="inset" className="border-r border-white/10">
      <SidebarHeader className="border-b border-white/10 bg-gradient-to-r from-purple-600/20 to-pink-600/20">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" asChild>
              <a href="/" className="group">
                <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-gradient-to-br from-orange-500 to-red-500 text-white shadow-lg">
                  <Bot className="size-4" />
                </div>
                <div className="grid flex-1 text-left text-sm leading-tight">
                  <span className="truncate font-semibold text-white font-ubuntu">Ubuntu Networks</span>
                  <span className="truncate text-xs text-orange-200">AI Platform</span>
                </div>
                <Badge variant="secondary" className="bg-orange-500/20 text-orange-200 border-orange-400/30">
                  Live
                </Badge>
              </a>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>
      <SidebarContent className="bg-slate-900/50 backdrop-blur-sm">
        <SidebarGroup>
          <SidebarGroupLabel className="text-purple-200 font-medium">Platform</SidebarGroupLabel>
          <SidebarMenu>
            {data.navMain.map((item) => (
              <Collapsible key={item.title} asChild defaultOpen={item.title === "AI Assistant"}>
                <SidebarMenuItem>
                  <SidebarMenuButton
                    asChild
                    tooltip={item.title}
                    isActive={item.isActive}
                    className="group hover:bg-purple-500/10 data-[active=true]:bg-purple-500/20 data-[active=true]:text-purple-200"
                  >
                    {item.items ? (
                      <CollapsibleTrigger className="w-full">
                        <item.icon className="text-purple-300" />
                        <span className="text-slate-200">{item.title}</span>
                        {item.badge && (
                          <Badge variant="secondary" className="ml-auto bg-purple-500 text-white text-xs">
                            {item.badge}
                          </Badge>
                        )}
                        <ChevronUp className="ml-auto transition-transform duration-200 group-data-[state=open]/collapsible:rotate-180 text-purple-300" />
                      </CollapsibleTrigger>
                    ) : (
                      <a href={item.url} className="flex items-center gap-2 w-full">
                        <item.icon className="text-purple-300" />
                        <span className="text-slate-200">{item.title}</span>
                        {item.badge && (
                          <Badge variant="secondary" className="ml-auto bg-purple-500 text-white text-xs">
                            {item.badge}
                          </Badge>
                        )}
                      </a>
                    )}
                  </SidebarMenuButton>
                  {item.items && (
                    <CollapsibleContent>
                      <SidebarMenuSub>
                        {item.items.map((subItem) => (
                          <SidebarMenuSubItem key={subItem.title}>
                            <SidebarMenuSubButton asChild className="hover:bg-purple-500/10">
                              <a href={subItem.url} className="group">
                                <subItem.icon className="size-4 text-purple-400" />
                                <div className="flex flex-col">
                                  <span className="text-slate-200 font-medium">{subItem.title}</span>
                                  <span className="text-xs text-slate-400">{subItem.description}</span>
                                </div>
                              </a>
                            </SidebarMenuSubButton>
                          </SidebarMenuSubItem>
                        ))}
                      </SidebarMenuSub>
                    </CollapsibleContent>
                  )}
                </SidebarMenuItem>
              </Collapsible>
            ))}
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="border-t border-white/10 bg-gradient-to-r from-purple-600/10 to-pink-600/10">
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <SidebarMenuButton size="lg" className="data-[state=open]:bg-purple-500/20 hover:bg-purple-500/10">
                  <Avatar className="h-8 w-8 rounded-lg border-2 border-purple-400/30">
                    <AvatarImage src={data.user.avatar || "/placeholder.svg"} alt={data.user.name} />
                    <AvatarFallback className="rounded-lg bg-gradient-to-br from-purple-500 to-pink-500 text-white">
                      SJ
                    </AvatarFallback>
                  </Avatar>
                  <div className="grid flex-1 text-left text-sm leading-tight">
                    <span className="truncate font-semibold text-white">{data.user.name}</span>
                    <span className="truncate text-xs text-purple-200">{data.user.role}</span>
                  </div>
                  <ChevronUp className="ml-auto size-4 text-purple-300" />
                </SidebarMenuButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                className="w-[--radix-dropdown-menu-trigger-width] min-w-56 rounded-lg bg-slate-800 border-slate-700"
                side="bottom"
                align="end"
                sideOffset={4}
              >
                <DropdownMenuItem className="hover:bg-purple-500/20 text-slate-200">
                  <Settings className="mr-2 h-4 w-4" />
                  Settings
                </DropdownMenuItem>
                <DropdownMenuItem className="hover:bg-purple-500/20 text-slate-200">
                  <HelpCircle className="mr-2 h-4 w-4" />
                  Support
                </DropdownMenuItem>
                <DropdownMenuItem className="hover:bg-red-500/20 text-red-300">Sign out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  )
}
