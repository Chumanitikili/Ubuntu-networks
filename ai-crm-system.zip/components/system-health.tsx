import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Activity, Server, Database, Wifi, Cpu, HardDrive } from "lucide-react"

const systemMetrics = [
  {
    name: "API Response Time",
    value: "145ms",
    status: "healthy",
    progress: 85,
    icon: Wifi,
  },
  {
    name: "Database Performance",
    value: "98.5%",
    status: "healthy",
    progress: 98,
    icon: Database,
  },
  {
    name: "Server Load",
    value: "23%",
    status: "healthy",
    progress: 23,
    icon: Server,
  },
  {
    name: "CPU Usage",
    value: "45%",
    status: "warning",
    progress: 45,
    icon: Cpu,
  },
  {
    name: "Storage Usage",
    value: "67%",
    status: "healthy",
    progress: 67,
    icon: HardDrive,
  },
]

const getStatusColor = (status: string) => {
  switch (status) {
    case "healthy":
      return "bg-green-500/20 text-green-300 border-green-400/30"
    case "warning":
      return "bg-yellow-500/20 text-yellow-300 border-yellow-400/30"
    case "critical":
      return "bg-red-500/20 text-red-300 border-red-400/30"
    default:
      return "bg-slate-500/20 text-slate-300 border-slate-400/30"
  }
}

export function SystemHealth() {
  return (
    <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-white flex items-center gap-2">
              <Activity className="h-5 w-5 text-green-400" />
              System Health
            </CardTitle>
            <CardDescription className="text-slate-400">Real-time infrastructure monitoring</CardDescription>
          </div>
          <Badge variant="secondary" className="bg-green-500/20 text-green-300 border-green-400/30">
            All Systems Operational
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {systemMetrics.map((metric) => (
          <div key={metric.name} className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <metric.icon className="h-4 w-4 text-slate-400" />
                <span className="text-sm font-medium text-slate-300">{metric.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-white">{metric.value}</span>
                <Badge variant="outline" className={getStatusColor(metric.status)}>
                  {metric.status}
                </Badge>
              </div>
            </div>
            <Progress value={metric.progress} className="h-2 bg-slate-700" />
          </div>
        ))}

        <div className="pt-4 border-t border-slate-700">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-lg font-bold text-green-400">99.9%</div>
              <div className="text-xs text-slate-400">Uptime</div>
            </div>
            <div>
              <div className="text-lg font-bold text-blue-400">2.1M</div>
              <div className="text-xs text-slate-400">Requests/day</div>
            </div>
            <div>
              <div className="text-lg font-bold text-purple-400">145ms</div>
              <div className="text-xs text-slate-400">Avg Response</div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
