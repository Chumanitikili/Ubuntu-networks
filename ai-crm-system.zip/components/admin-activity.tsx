import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Building2, CreditCard, AlertTriangle, UserPlus } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const activities = [
  {
    id: 1,
    type: "user_created",
    title: "New user registered",
    description: "John Smith joined TechCorp Inc as company admin",
    time: "5 minutes ago",
    status: "success",
    icon: UserPlus,
    user: "System",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 2,
    type: "company_created",
    title: "New company onboarded",
    description: "Startup.io signed up for 90-day POC trial",
    time: "1 hour ago",
    status: "info",
    icon: Building2,
    user: "Sales Team",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 3,
    type: "payment_received",
    title: "Payment processed",
    description: "Enterprise Corp upgraded to Premium plan - $2,499/month",
    time: "2 hours ago",
    status: "success",
    icon: CreditCard,
    user: "Billing System",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 4,
    type: "security_alert",
    title: "Security alert resolved",
    description: "Multiple failed login attempts from IP 192.168.1.100",
    time: "4 hours ago",
    status: "warning",
    icon: AlertTriangle,
    user: "Security System",
    avatar: "/placeholder.svg?height=32&width=32",
  },
]

const getStatusColor = (status: string) => {
  switch (status) {
    case "success":
      return "bg-green-500/20 text-green-300 border-green-400/30"
    case "info":
      return "bg-blue-500/20 text-blue-300 border-blue-400/30"
    case "warning":
      return "bg-yellow-500/20 text-yellow-300 border-yellow-400/30"
    case "error":
      return "bg-red-500/20 text-red-300 border-red-400/30"
    default:
      return "bg-slate-500/20 text-slate-300 border-slate-400/30"
  }
}

export function RecentActivity() {
  return (
    <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-white">System Activity</CardTitle>
        <CardDescription className="text-slate-400">Recent administrative events and system changes</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.map((activity) => (
          <div
            key={activity.id}
            className="flex items-start space-x-4 p-3 rounded-lg bg-slate-900/50 border border-slate-700 hover:bg-slate-900/70 transition-all duration-200"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-orange-500/20 to-red-500/20 border border-orange-400/30">
              <activity.icon className="h-5 w-5 text-orange-300" />
            </div>
            <div className="flex-1 space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-white">{activity.title}</p>
                <Badge variant="outline" className={getStatusColor(activity.status)}>
                  {activity.status}
                </Badge>
              </div>
              <p className="text-sm text-slate-400">{activity.description}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Avatar className="h-5 w-5">
                    <AvatarImage src={activity.avatar || "/placeholder.svg"} alt={activity.user} />
                    <AvatarFallback className="text-xs bg-gradient-to-br from-orange-500 to-red-500 text-white">
                      {activity.user
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-xs text-slate-400">{activity.user}</span>
                </div>
                <p className="text-xs text-slate-500">{activity.time}</p>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
