import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Phone, Mail, MessageSquare, Calendar, CheckCircle, Clock, AlertCircle } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const activities = [
  {
    id: 1,
    type: "call",
    title: "AI handled customer inquiry",
    description: "John Smith called about service pricing - resolved automatically",
    time: "2 minutes ago",
    status: "completed",
    icon: Phone,
    user: "AI Assistant",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 2,
    type: "email",
    title: "Re-engagement campaign sent",
    description: "Email sequence sent to 150 inactive leads with 32% open rate",
    time: "15 minutes ago",
    status: "in-progress",
    icon: Mail,
    user: "Campaign Bot",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 3,
    type: "chat",
    title: "Live chat escalation",
    description: "Customer inquiry about refund policy escalated to human agent",
    time: "32 minutes ago",
    status: "escalated",
    icon: MessageSquare,
    user: "Sarah Johnson",
    avatar: "/placeholder.svg?height=32&width=32",
  },
  {
    id: 4,
    type: "meeting",
    title: "Appointment scheduled",
    description: "AI scheduled follow-up call with Mike Davis for tomorrow 2 PM",
    time: "1 hour ago",
    status: "scheduled",
    icon: Calendar,
    user: "Scheduling Bot",
    avatar: "/placeholder.svg?height=32&width=32",
  },
]

const getStatusIcon = (status: string) => {
  switch (status) {
    case "completed":
      return <CheckCircle className="h-4 w-4 text-green-400" />
    case "in-progress":
      return <Clock className="h-4 w-4 text-blue-400" />
    case "escalated":
      return <AlertCircle className="h-4 w-4 text-red-400" />
    case "scheduled":
      return <Calendar className="h-4 w-4 text-purple-400" />
    default:
      return <Clock className="h-4 w-4 text-slate-400" />
  }
}

const getStatusColor = (status: string) => {
  switch (status) {
    case "completed":
      return "bg-green-500/20 text-green-300 border-green-400/30"
    case "in-progress":
      return "bg-blue-500/20 text-blue-300 border-blue-400/30"
    case "escalated":
      return "bg-red-500/20 text-red-300 border-red-400/30"
    case "scheduled":
      return "bg-purple-500/20 text-purple-300 border-purple-400/30"
    default:
      return "bg-slate-500/20 text-slate-300 border-slate-400/30"
  }
}

export function RecentActivity() {
  return (
    <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
      <CardHeader>
        <CardTitle className="text-white">Recent Activity</CardTitle>
        <CardDescription className="text-slate-400">Latest AI interactions and system events</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {activities.map((activity) => (
          <div
            key={activity.id}
            className="flex items-start space-x-4 p-3 rounded-lg bg-slate-900/50 border border-slate-700 hover:bg-slate-900/70 transition-all duration-200"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-purple-500/20 to-pink-500/20 border border-purple-400/30">
              <activity.icon className="h-5 w-5 text-purple-300" />
            </div>
            <div className="flex-1 space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium text-white">{activity.title}</p>
                <div className="flex items-center gap-2">
                  {getStatusIcon(activity.status)}
                  <Badge variant="outline" className={getStatusColor(activity.status)}>
                    {activity.status}
                  </Badge>
                </div>
              </div>
              <p className="text-sm text-slate-400">{activity.description}</p>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Avatar className="h-5 w-5">
                    <AvatarImage src={activity.avatar || "/placeholder.svg"} alt={activity.user} />
                    <AvatarFallback className="text-xs bg-gradient-to-br from-purple-500 to-pink-500 text-white">
                      {activity.user
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <span className="text-xs text-slate-400">{activity.user}</span>
                </div>
                <p className="text-xs text-slate-500">{activity.time}</p>
              </div>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
