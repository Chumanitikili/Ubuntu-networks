import { Bell, Search, Settings, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { SidebarTrigger } from "@/components/ui/sidebar"

export function AdminHeader() {
  return (
    <header className="sticky top-0 z-50 flex h-16 shrink-0 items-center gap-2 border-b border-white/10 bg-slate-900/80 backdrop-blur-md px-6">
      <SidebarTrigger className="-ml-1 text-orange-300 hover:bg-orange-500/20" />
      <div className="flex flex-1 items-center justify-between">
        <div className="flex items-center gap-3">
          <h1 className="text-xl font-bold bg-gradient-to-r from-orange-400 to-red-400 bg-clip-text text-transparent font-ubuntu">
            System Administration
          </h1>
          <Badge variant="secondary" className="bg-green-500/20 text-green-300 border-green-400/30 animate-pulse">
            <div className="w-2 h-2 bg-green-400 rounded-full mr-1" />
            All Systems Operational
          </Badge>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
            <Input
              placeholder="Search users, companies..."
              className="pl-10 w-80 bg-slate-800/50 border-slate-700 text-slate-200 placeholder:text-slate-400 focus:border-orange-400"
            />
          </div>
          <Button
            variant="outline"
            size="icon"
            className="relative border-slate-700 bg-slate-800/50 hover:bg-orange-500/20 text-slate-300"
          >
            <AlertTriangle className="h-4 w-4" />
            <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 text-xs bg-red-500 text-white">3</Badge>
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="relative border-slate-700 bg-slate-800/50 hover:bg-orange-500/20 text-slate-300"
          >
            <Bell className="h-4 w-4" />
            <Badge className="absolute -top-1 -right-1 h-5 w-5 rounded-full p-0 text-xs bg-orange-500 text-white">
              7
            </Badge>
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="border-slate-700 bg-slate-800/50 hover:bg-orange-500/20 text-slate-300"
          >
            <Settings className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </header>
  )
}
