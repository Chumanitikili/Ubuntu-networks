import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { TrendingUp, Brain } from "lucide-react"

export function AIInsights() {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5" />
          AI Insights
        </CardTitle>
        <CardDescription>Real-time AI performance metrics</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>Call Resolution Rate</span>
            <span className="font-medium">94%</span>
          </div>
          <Progress value={94} className="h-2" />
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>Lead Qualification Accuracy</span>
            <span className="font-medium">87%</span>
          </div>
          <Progress value={87} className="h-2" />
        </div>
        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span>Campaign Engagement</span>
            <span className="font-medium">76%</span>
          </div>
          <Progress value={76} className="h-2" />
        </div>
        <div className="pt-2 border-t">
          <div className="flex items-center gap-2 text-sm text-green-600">
            <TrendingUp className="h-4 w-4" />
            <span>AI efficiency improved by 15% this week</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
