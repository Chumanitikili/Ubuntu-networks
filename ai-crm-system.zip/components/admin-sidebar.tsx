"use client"
import {
  Network,
  Shield,
  Users,
  Building2,
  BarChart3,
  Settings,
  Database,
  Activity,
  CreditCard,
  AlertTriangle,
  Clock,
  ChevronUp,
  HelpCircle,
} from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

const adminNavigation = [
  {
    title: "System Overview",
    url: "/admin",
    icon: BarChart3,
    isActive: true,
  },
  {
    title: "User Management",
    url: "/admin/users",
    icon: Users,
  },
  {
    title: "Company Management",
    url: "/admin/companies",
    icon: Building2,
  },
  {
    title: "POC Accounts",
    url: "/admin/poc",
    icon: Clock,
    badge: "12",
  },
  {
    title: "System Health",
    url: "/admin/health",
    icon: Activity,
  },
  {
    title: "Billing & Usage",
    url: "/admin/billing",
    icon: CreditCard,
  },
  {
    title: "Security",
    url: "/admin/security",
    icon: Shield,
  },
  {
    title: "Database",
    url: "/admin/database",
    icon: Database,
  },
  {
    title: "Alerts",
    url: "/admin/alerts",
    icon: AlertTriangle,
    badge: "3",
  },
  {
    title: "Settings",
    url: "/admin/settings",
    icon: Settings,
  },
]

export function AdminSidebar() {
  return (
    <Sidebar variant="inset" className="border-r border-white/10">
      <SidebarHeader className="border-b border-white/10 bg-gradient-to-r from-orange-600/20 to-red-600/20">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton size="lg" asChild>
              <a href="/admin" className="group">
                <div className="flex aspect-square size-8 items-center justify-center rounded-lg bg-gradient-to-br from-orange-500 to-red-500 text-white shadow-lg">
                  <Network className="size-4" />
                </div>
                <div className="grid flex-1 text-left text-sm leading-tight">
                  <span className="truncate font-semibold text-white font-ubuntu">Ubuntu Networks</span>
                  <span className="truncate text-xs text-orange-200">Admin Portal</span>
                </div>
                <Badge variant="secondary" className="bg-red-500/20 text-red-200 border-red-400/30">
                  Admin
                </Badge>
              </a>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>
      <SidebarContent className="bg-slate-900/50 backdrop-blur-sm">
        <SidebarGroup>
          <SidebarGroupLabel className="text-orange-200 font-medium">System Administration</SidebarGroupLabel>
          <SidebarMenu>
            {adminNavigation.map((item) => (
              <SidebarMenuItem key={item.title}>
                <SidebarMenuButton
                  asChild
                  isActive={item.isActive}
                  className="group hover:bg-orange-500/10 data-[active=true]:bg-orange-500/20 data-[active=true]:text-orange-200"
                >
                  <a href={item.url} className="flex items-center gap-2 w-full">
                    <item.icon className="text-orange-300" />
                    <span className="text-slate-200">{item.title}</span>
                    {item.badge && (
                      <Badge variant="secondary" className="ml-auto bg-orange-500 text-white text-xs">
                        {item.badge}
                      </Badge>
                    )}
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarGroup>
      </SidebarContent>
      <SidebarFooter className="border-t border-white/10 bg-gradient-to-r from-orange-600/10 to-red-600/10">
        <SidebarMenu>
          <SidebarMenuItem>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <SidebarMenuButton size="lg" className="data-[state=open]:bg-orange-500/20 hover:bg-orange-500/10">
                  <Avatar className="h-8 w-8 rounded-lg border-2 border-orange-400/30">
                    <AvatarImage src="/placeholder.svg" alt="Admin User" />
                    <AvatarFallback className="rounded-lg bg-gradient-to-br from-orange-500 to-red-500 text-white">
                      AU
                    </AvatarFallback>
                  </Avatar>
                  <div className="grid flex-1 text-left text-sm leading-tight">
                    <span className="truncate font-semibold text-white">System Admin</span>
                    <span className="truncate text-xs text-orange-200">admin@ubuntu-networks.com</span>
                  </div>
                  <ChevronUp className="ml-auto size-4 text-orange-300" />
                </SidebarMenuButton>
              </DropdownMenuTrigger>
              <DropdownMenuContent
                className="w-[--radix-dropdown-menu-trigger-width] min-w-56 rounded-lg bg-slate-800 border-slate-700"
                side="bottom"
                align="end"
                sideOffset={4}
              >
                <DropdownMenuItem className="hover:bg-orange-500/20 text-slate-200">
                  <Settings className="mr-2 h-4 w-4" />
                  Admin Settings
                </DropdownMenuItem>
                <DropdownMenuItem className="hover:bg-orange-500/20 text-slate-200">
                  <HelpCircle className="mr-2 h-4 w-4" />
                  System Docs
                </DropdownMenuItem>
                <DropdownMenuItem className="hover:bg-red-500/20 text-red-300">Sign out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  )
}
