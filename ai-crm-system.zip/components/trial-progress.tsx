import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Clock, Star, Calendar, TrendingUp } from "lucide-react"

export function TrialProgress() {
  const daysRemaining = 67
  const totalDays = 90
  const progressPercentage = ((totalDays - daysRemaining) / totalDays) * 100

  return (
    <Card className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 border-blue-400/30 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-white flex items-center gap-2">
              <Clock className="h-5 w-5 text-blue-400" />
              90-Day Trial Progress
            </CardTitle>
            <CardDescription className="text-blue-200">
              Experience the full power of Ubuntu Networks AI platform
            </CardDescription>
          </div>
          <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600">
            <Star className="mr-2 h-4 w-4" />
            Upgrade Now
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="text-center">
            <div className="text-2xl font-bold text-white">{daysRemaining}</div>
            <div className="text-sm text-blue-200">Days Remaining</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-white">23</div>
            <div className="text-sm text-blue-200">Days Used</div>
          </div>
          <div className="text-center">
            <div className="text-2xl font-bold text-white">247</div>
            <div className="text-sm text-blue-200">Calls Handled</div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-blue-200">Trial Progress</span>
            <span className="text-white font-medium">{Math.round(progressPercentage)}% Complete</span>
          </div>
          <Progress value={progressPercentage} className="h-3 bg-slate-700" />
        </div>

        <div className="flex items-center justify-between p-3 bg-blue-500/10 rounded-lg border border-blue-400/20">
          <div className="flex items-center gap-2">
            <Calendar className="h-4 w-4 text-blue-400" />
            <span className="text-sm text-blue-200">Trial expires on March 15, 2024</span>
          </div>
          <Badge variant="outline" className="bg-blue-500/20 text-blue-300 border-blue-400/30">
            <TrendingUp className="h-3 w-3 mr-1" />
            Active
          </Badge>
        </div>
      </CardContent>
    </Card>
  )
}
