import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Phone, PhoneCall, Clock, MapPin, MessageSquare } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"

const activeCalls = [
  {
    id: 1,
    caller: "John Smith",
    phone: "+1 (555) 123-4567",
    location: "New York, NY",
    duration: "2:34",
    status: "in-progress",
    intent: "Service inquiry",
    avatar: "/placeholder.svg?height=32&width=32",
    aiConfidence: 94,
  },
  {
    id: 2,
    caller: "Sarah Johnson",
    phone: "+1 (555) 234-5678",
    location: "Los Angeles, CA",
    duration: "1:12",
    status: "in-progress",
    intent: "Appointment booking",
    avatar: "/placeholder.svg?height=32&width=32",
    aiConfidence: 87,
  },
  {
    id: 3,
    caller: "Mike Davis",
    phone: "+1 (555) 345-6789",
    location: "Chicago, IL",
    duration: "0:45",
    status: "escalated",
    intent: "Technical support",
    avatar: "/placeholder.svg?height=32&width=32",
    aiConfidence: 62,
  },
]

export function LiveCallMonitor() {
  return (
    <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-white flex items-center gap-2">
              <PhoneCall className="h-5 w-5 text-green-400" />
              Live Call Monitor
            </CardTitle>
            <CardDescription className="text-slate-400">Real-time AI call handling and monitoring</CardDescription>
          </div>
          <Badge variant="secondary" className="bg-green-500/20 text-green-300 border-green-400/30">
            {activeCalls.length} Active
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {activeCalls.map((call) => (
          <div
            key={call.id}
            className="flex items-center justify-between p-4 rounded-lg bg-slate-900/50 border border-slate-700 hover:bg-slate-900/70 transition-all duration-200"
          >
            <div className="flex items-center gap-4">
              <Avatar className="h-10 w-10 border-2 border-purple-400/30">
                <AvatarImage src={call.avatar || "/placeholder.svg"} alt={call.caller} />
                <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white">
                  {call.caller
                    .split(" ")
                    .map((n) => n[0])
                    .join("")}
                </AvatarFallback>
              </Avatar>
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <h3 className="font-medium text-white">{call.caller}</h3>
                  <Badge
                    variant={call.status === "in-progress" ? "secondary" : "destructive"}
                    className={
                      call.status === "in-progress"
                        ? "bg-green-500/20 text-green-300 border-green-400/30"
                        : "bg-red-500/20 text-red-300 border-red-400/30"
                    }
                  >
                    {call.status === "in-progress" ? "Active" : "Escalated"}
                  </Badge>
                </div>
                <div className="flex items-center gap-4 text-sm text-slate-400">
                  <span className="flex items-center gap-1">
                    <Phone className="h-3 w-3" />
                    {call.phone}
                  </span>
                  <span className="flex items-center gap-1">
                    <MapPin className="h-3 w-3" />
                    {call.location}
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {call.duration}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-400">Intent:</span>
                  <span className="text-xs text-purple-300">{call.intent}</span>
                  <span className="text-xs text-slate-400">•</span>
                  <span className="text-xs text-green-400">AI Confidence: {call.aiConfidence}%</span>
                </div>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                className="border-slate-600 bg-slate-800 hover:bg-purple-500/20 text-slate-300"
              >
                <MessageSquare className="h-4 w-4 mr-1" />
                Join
              </Button>
              <Button
                variant="outline"
                size="sm"
                className="border-slate-600 bg-slate-800 hover:bg-red-500/20 text-slate-300"
              >
                <Phone className="h-4 w-4 mr-1" />
                Transfer
              </Button>
            </div>
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
