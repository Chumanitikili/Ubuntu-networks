import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Phone, MessageSquare, BarChart3, Users, Calendar, Star, CheckCircle, Lock } from "lucide-react"

const features = [
  {
    title: "AI Receptionist",
    description: "Intelligent call handling with natural language processing",
    icon: Phone,
    status: "active",
    usage: 85,
    limit: "Unlimited calls",
  },
  {
    title: "Smart Analytics",
    description: "Real-time insights and performance metrics",
    icon: BarChart3,
    status: "active",
    usage: 67,
    limit: "Full analytics suite",
  },
  {
    title: "Contact Management",
    description: "Organize and manage your customer database",
    icon: Users,
    status: "active",
    usage: 45,
    limit: "Up to 1,000 contacts",
  },
  {
    title: "AI Chat Support",
    description: "24/7 automated customer support chatbot",
    icon: MessageSquare,
    status: "active",
    usage: 92,
    limit: "Unlimited conversations",
  },
  {
    title: "Appointment Scheduling",
    description: "Automated booking and calendar management",
    icon: Calendar,
    status: "limited",
    usage: 30,
    limit: "Basic scheduling only",
  },
  {
    title: "Advanced Integrations",
    description: "Connect with CRM, email, and other tools",
    icon: Star,
    status: "locked",
    usage: 0,
    limit: "Available in full version",
  },
]

const getStatusColor = (status: string) => {
  switch (status) {
    case "active":
      return "bg-green-500/20 text-green-300 border-green-400/30"
    case "limited":
      return "bg-yellow-500/20 text-yellow-300 border-yellow-400/30"
    case "locked":
      return "bg-red-500/20 text-red-300 border-red-400/30"
    default:
      return "bg-slate-500/20 text-slate-300 border-slate-400/30"
  }
}

const getStatusIcon = (status: string) => {
  switch (status) {
    case "active":
      return <CheckCircle className="h-4 w-4" />
    case "limited":
      return <Star className="h-4 w-4" />
    case "locked":
      return <Lock className="h-4 w-4" />
    default:
      return <CheckCircle className="h-4 w-4" />
  }
}

export function POCFeatures() {
  return (
    <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-white">Trial Features</CardTitle>
            <CardDescription className="text-slate-400">
              Explore Ubuntu Networks capabilities during your 90-day trial
            </CardDescription>
          </div>
          <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600">
            <Star className="mr-2 h-4 w-4" />
            Upgrade to Full
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {features.map((feature) => (
          <div
            key={feature.title}
            className="p-4 rounded-lg bg-slate-900/50 border border-slate-700 hover:bg-slate-900/70 transition-all duration-200"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="p-2 rounded-lg bg-gradient-to-br from-blue-500/20 to-cyan-500/20 border border-blue-400/30">
                  <feature.icon className="h-5 w-5 text-blue-300" />
                </div>
                <div>
                  <h3 className="font-medium text-white">{feature.title}</h3>
                  <p className="text-sm text-slate-400">{feature.description}</p>
                </div>
              </div>
              <Badge variant="outline" className={getStatusColor(feature.status)}>
                {getStatusIcon(feature.status)}
                <span className="ml-1 capitalize">{feature.status}</span>
              </Badge>
            </div>

            {feature.status !== "locked" && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-slate-400">Usage</span>
                  <span className="text-white">{feature.usage}%</span>
                </div>
                <Progress value={feature.usage} className="h-2 bg-slate-700" />
                <div className="text-xs text-slate-500">{feature.limit}</div>
              </div>
            )}

            {feature.status === "locked" && (
              <div className="text-center py-2">
                <p className="text-sm text-slate-500">{feature.limit}</p>
              </div>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  )
}
