import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { TrendingUp, Brain, Zap, Target } from "lucide-react"
import { Badge } from "@/components/ui/badge"

const metrics = [
  {
    label: "Call Resolution",
    value: 94,
    target: 90,
    trend: "+3%",
    color: "bg-green-500",
  },
  {
    label: "Response Accuracy",
    value: 87,
    target: 85,
    trend: "+5%",
    color: "bg-blue-500",
  },
  {
    label: "Customer Satisfaction",
    value: 92,
    target: 88,
    trend: "+7%",
    color: "bg-purple-500",
  },
  {
    label: "Lead Qualification",
    value: 89,
    target: 80,
    trend: "+12%",
    color: "bg-orange-500",
  },
]

export function AIPerformance() {
  return (
    <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-white flex items-center gap-2">
              <Brain className="h-5 w-5 text-purple-400" />
              AI Performance
            </CardTitle>
            <CardDescription className="text-slate-400">Real-time AI metrics and optimization</CardDescription>
          </div>
          <Badge variant="secondary" className="bg-purple-500/20 text-purple-300 border-purple-400/30">
            <Zap className="h-3 w-3 mr-1" />
            Optimized
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {metrics.map((metric) => (
          <div key={metric.label} className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="text-slate-300 font-medium">{metric.label}</span>
              <div className="flex items-center gap-2">
                <span className="text-white font-bold">{metric.value}%</span>
                <span className="text-green-400 text-xs flex items-center gap-1">
                  <TrendingUp className="h-3 w-3" />
                  {metric.trend}
                </span>
              </div>
            </div>
            <div className="relative">
              <Progress value={metric.value} className="h-2 bg-slate-700" />
              <div
                className="absolute top-0 h-2 rounded-full transition-all duration-500"
                style={{
                  width: `${metric.value}%`,
                  background: `linear-gradient(90deg, ${metric.color}, ${metric.color}dd)`,
                }}
              />
              <div
                className="absolute top-0 w-0.5 h-2 bg-yellow-400 opacity-60"
                style={{ left: `${metric.target}%` }}
                title={`Target: ${metric.target}%`}
              />
            </div>
            <div className="flex items-center justify-between text-xs text-slate-400">
              <span>Target: {metric.target}%</span>
              <span className="flex items-center gap-1">
                <Target className="h-3 w-3" />
                {metric.value >= metric.target ? "Above target" : "Below target"}
              </span>
            </div>
          </div>
        ))}

        <div className="pt-4 border-t border-slate-700">
          <div className="flex items-center gap-2 text-sm text-green-400">
            <TrendingUp className="h-4 w-4" />
            <span>AI efficiency improved by 15% this week</span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
