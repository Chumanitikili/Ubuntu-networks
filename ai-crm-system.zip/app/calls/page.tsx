import { AppSidebar } from "@/components/app-sidebar"
import { SidebarInset } from "@/components/ui/sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Phone, PhoneCall, Clock, MapPin, MessageSquare, PhoneOff, Volume2 } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Progress } from "@/components/ui/progress"

const activeCalls = [
  {
    id: 1,
    caller: "John Smith",
    phone: "+1 (555) 123-4567",
    location: "New York, NY",
    duration: "4:23",
    status: "active",
    intent: "Service inquiry",
    avatar: "/placeholder.svg?height=40&width=40",
    aiConfidence: 94,
    transcript: "Hi, I'm calling to inquire about your premium service package...",
  },
  {
    id: 2,
    caller: "Sarah Johnson",
    phone: "+1 (555) 234-5678",
    location: "Los Angeles, CA",
    duration: "2:15",
    status: "active",
    intent: "Appointment booking",
    avatar: "/placeholder.svg?height=40&width=40",
    aiConfidence: 87,
    transcript: "I'd like to schedule an appointment for next week...",
  },
  {
    id: 3,
    caller: "Mike Davis",
    phone: "+1 (555) 345-6789",
    location: "Chicago, IL",
    duration: "1:45",
    status: "hold",
    intent: "Technical support",
    avatar: "/placeholder.svg?height=40&width=40",
    aiConfidence: 62,
    transcript: "I'm having trouble with my account login...",
  },
]

export default function CallsPage() {
  return (
    <>
      <AppSidebar />
      <SidebarInset>
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
          <DashboardHeader />
          <div className="flex flex-1 flex-col gap-6 p-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-white">Live Call Center</h1>
                <p className="text-slate-400">Monitor and manage active calls in real-time</p>
              </div>
              <div className="flex items-center gap-3">
                <Badge variant="secondary" className="bg-green-500/20 text-green-300 border-green-400/30">
                  <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse" />
                  {activeCalls.length} Active Calls
                </Badge>
                <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                  <PhoneCall className="mr-2 h-4 w-4" />
                  Start New Call
                </Button>
              </div>
            </div>

            <div className="grid gap-6 lg:grid-cols-2 xl:grid-cols-3">
              {activeCalls.map((call) => (
                <Card
                  key={call.id}
                  className="bg-slate-800/50 border-slate-700 backdrop-blur-sm hover:bg-slate-800/70 transition-all duration-200"
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-12 w-12 border-2 border-purple-400/30">
                          <AvatarImage src={call.avatar || "/placeholder.svg"} alt={call.caller} />
                          <AvatarFallback className="bg-gradient-to-br from-purple-500 to-pink-500 text-white">
                            {call.caller
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="font-semibold text-white">{call.caller}</h3>
                          <p className="text-sm text-slate-400">{call.phone}</p>
                        </div>
                      </div>
                      <Badge
                        variant={call.status === "active" ? "secondary" : "outline"}
                        className={
                          call.status === "active"
                            ? "bg-green-500/20 text-green-300 border-green-400/30"
                            : "bg-yellow-500/20 text-yellow-300 border-yellow-400/30"
                        }
                      >
                        {call.status === "active" ? "Live" : "On Hold"}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div className="flex items-center gap-2 text-slate-400">
                        <MapPin className="h-4 w-4" />
                        <span>{call.location}</span>
                      </div>
                      <div className="flex items-center gap-2 text-slate-400">
                        <Clock className="h-4 w-4" />
                        <span>{call.duration}</span>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-slate-400">Call Intent:</span>
                        <span className="text-purple-300 font-medium">{call.intent}</span>
                      </div>
                      <div className="space-y-1">
                        <div className="flex items-center justify-between text-sm">
                          <span className="text-slate-400">AI Confidence:</span>
                          <span className="text-white font-medium">{call.aiConfidence}%</span>
                        </div>
                        <Progress value={call.aiConfidence} className="h-2 bg-slate-700" />
                      </div>
                    </div>

                    <div className="space-y-2">
                      <span className="text-sm text-slate-400">Live Transcript:</span>
                      <div className="p-3 bg-slate-900/50 rounded-lg border border-slate-700">
                        <p className="text-sm text-slate-300 italic">"{call.transcript}"</p>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        className="flex-1 border-slate-600 bg-slate-800 hover:bg-green-500/20 text-slate-300"
                      >
                        <MessageSquare className="h-4 w-4 mr-1" />
                        Join
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-slate-600 bg-slate-800 hover:bg-blue-500/20 text-slate-300"
                      >
                        <Volume2 className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-slate-600 bg-slate-800 hover:bg-red-500/20 text-slate-300"
                      >
                        <PhoneOff className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="text-white">Call Queue</CardTitle>
                <CardDescription className="text-slate-400">Incoming calls waiting for AI response</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <Phone className="h-12 w-12 text-slate-600 mx-auto mb-4" />
                  <p className="text-slate-400">No calls in queue</p>
                  <p className="text-sm text-slate-500">All incoming calls are being handled efficiently</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </SidebarInset>
    </>
  )
}
