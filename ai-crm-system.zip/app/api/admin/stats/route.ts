import { NextResponse } from "next/server"

export async function GET() {
  // Mock admin statistics - in production, this would query your database
  const stats = {
    totalUsers: 12847,
    activeCompanies: 156,
    pocAccounts: 23,
    monthlyRevenue: 245231,
    systemHealth: {
      uptime: 99.9,
      apiResponseTime: 145,
      databasePerformance: 98.5,
      serverLoad: 23,
      cpuUsage: 45,
      storageUsage: 67,
    },
    recentActivity: [
      {
        id: 1,
        type: "user_created",
        title: "New user registered",
        description: "John Smith joined TechCorp Inc as company admin",
        timestamp: new Date(Date.now() - 5 * 60 * 1000).toISOString(),
        status: "success",
      },
      {
        id: 2,
        type: "company_created",
        title: "New company onboarded",
        description: "Startup.io signed up for 90-day POC trial",
        timestamp: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
        status: "info",
      },
    ],
    userGrowth: {
      daily: 45,
      weekly: 312,
      monthly: 1247,
    },
    revenueGrowth: {
      daily: 8234,
      weekly: 57643,
      monthly: 245231,
    },
  }

  return NextResponse.json(stats)
}
