import { type NextRequest, NextResponse } from "next/server"
import { cookies } from "next/headers"

// Mock session store - in production, this would be Redis or database
const sessions = new Map<string, string>()

// Mock user database
const users = [
  {
    id: "1",
    email: "admin@ubuntu-networks.com",
    name: "System Admin",
    role: "admin" as const,
    isActive: true,
    permissions: ["*"],
  },
  {
    id: "2",
    email: "super@ubuntu-networks.com",
    name: "Super User",
    role: "superuser" as const,
    isActive: true,
    permissions: ["manage_companies", "manage_users", "view_analytics"],
  },
  {
    id: "3",
    email: "company@techcorp.com",
    name: "John Smith",
    role: "company_admin" as const,
    companyId: "comp_1",
    companyName: "TechCorp Inc",
    isActive: true,
    permissions: ["manage_company_users", "view_company_analytics"],
  },
  {
    id: "4",
    email: "trial@startup.io",
    name: "Sarah Johnson",
    role: "poc_user" as const,
    companyId: "comp_2",
    companyName: "Startup.io",
    trialExpiresAt: "2024-03-15T00:00:00Z",
    isActive: true,
    permissions: ["view_trial_features"],
  },
]

export async function GET(req: NextRequest) {
  try {
    const cookieStore = await cookies()
    const sessionToken = cookieStore.get("session")?.value

    if (!sessionToken) {
      return NextResponse.json({ error: "No session found" }, { status: 401 })
    }

    // Extract user ID from session token (simplified for demo)
    const userId = sessionToken.split("_")[1]
    const user = users.find((u) => u.id === userId)

    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 401 })
    }

    if (!user.isActive) {
      return NextResponse.json({ error: "Account is inactive" }, { status: 401 })
    }

    return NextResponse.json({ user })
  } catch (error) {
    console.error("Auth check error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
