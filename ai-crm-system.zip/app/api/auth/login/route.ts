import { type NextRequest, NextResponse } from "next/server"
import { cookies } from "next/headers"

// Mock user database - in production, this would be a real database
const users = [
  {
    id: "1",
    email: "admin@ubuntu-networks.com",
    password: "admin123", // In production, this would be hashed
    name: "System Admin",
    role: "admin" as const,
    isActive: true,
    permissions: ["*"],
  },
  {
    id: "2",
    email: "super@ubuntu-networks.com",
    password: "super123",
    name: "Super User",
    role: "superuser" as const,
    isActive: true,
    permissions: ["manage_companies", "manage_users", "view_analytics"],
  },
  {
    id: "3",
    email: "company@techcorp.com",
    password: "company123",
    name: "John Smith",
    role: "company_admin" as const,
    companyId: "comp_1",
    companyName: "TechCorp Inc",
    isActive: true,
    permissions: ["manage_company_users", "view_company_analytics"],
  },
  {
    id: "4",
    email: "trial@startup.io",
    password: "trial123",
    name: "Sarah Johnson",
    role: "poc_user" as const,
    companyId: "comp_2",
    companyName: "Startup.io",
    trialExpiresAt: "2024-03-15T00:00:00Z",
    isActive: true,
    permissions: ["view_trial_features"],
  },
  {
    id: "5",
    email: "user@company.com",
    password: "user123",
    name: "Mike Davis",
    role: "user" as const,
    companyId: "comp_1",
    companyName: "TechCorp Inc",
    isActive: true,
    permissions: ["view_dashboard", "make_calls"],
  },
]

export async function POST(req: NextRequest) {
  try {
    const { email, password } = await req.json()

    // Find user by email
    const user = users.find((u) => u.email === email && u.password === password)

    if (!user) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    if (!user.isActive) {
      return NextResponse.json({ error: "Account is inactive" }, { status: 401 })
    }

    // Check if trial user's trial has expired
    if (user.role === "poc_user" && user.trialExpiresAt) {
      const trialExpiry = new Date(user.trialExpiresAt)
      if (trialExpiry < new Date()) {
        return NextResponse.json({ error: "Trial has expired" }, { status: 401 })
      }
    }

    // Create session token (in production, use proper JWT or session management)
    const sessionToken = `session_${user.id}_${Date.now()}`

    // Set session cookie
    const cookieStore = await cookies()
    cookieStore.set("session", sessionToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    })

    // Return user data (excluding password)
    const { password: _, ...userWithoutPassword } = user

    return NextResponse.json({
      user: userWithoutPassword,
      sessionToken,
    })
  } catch (error) {
    console.error("Login error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
