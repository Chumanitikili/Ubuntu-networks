import { type NextRequest, NextResponse } from "next/server"

// Mock data - in production, this would connect to your database
const leads = [
  {
    id: 1,
    name: "John Smith",
    email: "john@example.com",
    phone: "+1 (555) 123-4567",
    status: "hot",
    source: "Website",
    score: 85,
    lastContact: "2 hours ago",
    createdAt: new Date().toISOString(),
  },
  {
    id: 2,
    name: "Sarah Johnson",
    email: "sarah@example.com",
    phone: "+1 (555) 234-5678",
    status: "warm",
    source: "Referral",
    score: 72,
    lastContact: "1 day ago",
    createdAt: new Date().toISOString(),
  },
]

export async function GET() {
  return NextResponse.json({ leads })
}

export async function POST(req: NextRequest) {
  try {
    const leadData = await req.json()

    // In production, save to database
    const newLead = {
      id: leads.length + 1,
      ...leadData,
      createdAt: new Date().toISOString(),
      score: Math.floor(Math.random() * 100), // AI-generated score
    }

    leads.push(newLead)

    return NextResponse.json({ lead: newLead }, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create lead" }, { status: 500 })
  }
}
