import { type NextRequest, NextResponse } from "next/server"

// Mock active calls data - in production, this would connect to your telephony system
const activeCalls = [
  {
    id: 1,
    caller: "John Smith",
    phone: "+1 (555) 123-4567",
    location: "New York, NY",
    duration: "4:23",
    status: "active",
    intent: "Service inquiry",
    aiConfidence: 94,
    transcript: "Hi, I'm calling to inquire about your premium service package...",
    startTime: new Date(Date.now() - 263000).toISOString(), // 4:23 ago
  },
  {
    id: 2,
    caller: "Sarah Johnson",
    phone: "+1 (555) 234-5678",
    location: "Los Angeles, CA",
    duration: "2:15",
    status: "active",
    intent: "Appointment booking",
    aiConfidence: 87,
    transcript: "I'd like to schedule an appointment for next week...",
    startTime: new Date(Date.now() - 135000).toISOString(), // 2:15 ago
  },
]

export async function GET() {
  return NextResponse.json({
    calls: activeCalls,
    totalActive: activeCalls.length,
    timestamp: new Date().toISOString(),
  })
}

export async function POST(req: NextRequest) {
  try {
    const { action, callId, data } = await req.json()

    switch (action) {
      case "join":
        // In production, this would connect the agent to the call
        return NextResponse.json({ success: true, message: "Joined call successfully" })

      case "transfer":
        // In production, this would transfer the call to another agent/department
        return NextResponse.json({ success: true, message: "Call transferred successfully" })

      case "end":
        // In production, this would end the call
        return NextResponse.json({ success: true, message: "Call ended successfully" })

      default:
        return NextResponse.json({ error: "Invalid action" }, { status: 400 })
    }
  } catch (error) {
    return NextResponse.json({ error: "Failed to process call action" }, { status: 500 })
  }
}
