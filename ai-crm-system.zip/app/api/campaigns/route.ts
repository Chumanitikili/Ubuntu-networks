import { type NextRequest, NextResponse } from "next/server"

const campaigns = [
  {
    id: 1,
    name: "Inactive Lead Revival",
    type: "email",
    status: "active",
    contacts: 1247,
    openRate: 24.8,
    clickRate: 5.2,
    createdAt: new Date().toISOString(),
  },
  {
    id: 2,
    name: "SMS Follow-up",
    type: "sms",
    status: "active",
    contacts: 892,
    openRate: 89.2,
    clickRate: 12.4,
    createdAt: new Date().toISOString(),
  },
]

export async function GET() {
  return NextResponse.json({ campaigns })
}

export async function POST(req: NextRequest) {
  try {
    const campaignData = await req.json()

    const newCampaign = {
      id: campaigns.length + 1,
      ...campaignData,
      status: "draft",
      contacts: 0,
      openRate: 0,
      clickRate: 0,
      createdAt: new Date().toISOString(),
    }

    campaigns.push(newCampaign)

    return NextResponse.json({ campaign: newCampaign }, { status: 201 })
  } catch (error) {
    return NextResponse.json({ error: "Failed to create campaign" }, { status: 500 })
  }
}
