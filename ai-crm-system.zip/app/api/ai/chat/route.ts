import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const { message, context } = await req.json()

    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: `You are an AI assistant for a CRM system. You help with customer inquiries, lead qualification, and provide information about products and services. 
      
      Context: ${context || "General customer support"}
      
      Be helpful, professional, and concise in your responses.`,
      prompt: message,
    })

    return NextResponse.json({ response: text })
  } catch (error) {
    console.error("AI Chat Error:", error)
    return NextResponse.json({ error: "Failed to generate response" }, { status: 500 })
  }
}
