import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const { message, context, voiceSettings } = await req.json()

    const { text } = await generateText({
      model: openai("gpt-4o"),
      system: `You are Rosie, an AI receptionist for a professional call center. You are helpful, friendly, and efficient.
      
      Voice Settings: ${JSON.stringify(voiceSettings)}
      Context: ${context || "General customer service"}
      
      Guidelines:
      - Be professional but warm
      - Keep responses concise and clear
      - Always offer to help or escalate when needed
      - Use natural, conversational language
      - Acknowledge the caller's needs promptly`,
      prompt: message,
    })

    return NextResponse.json({
      response: text,
      voiceSettings: voiceSettings || {
        speed: 1.0,
        pitch: 1.0,
        voice: "professional",
      },
    })
  } catch (error) {
    console.error("AI Voice Error:", error)
    return NextResponse.json({ error: "Failed to generate voice response" }, { status: 500 })
  }
}
