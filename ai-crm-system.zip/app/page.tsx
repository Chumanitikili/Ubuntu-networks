import { AppSidebar } from "@/components/app-sidebar"
import { SidebarInset } from "@/components/ui/sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { DashboardStats } from "@/components/dashboard-stats"
import { LiveCallMonitor } from "@/components/live-call-monitor"
import { AIPerformance } from "@/components/ai-performance"
import { QuickActions } from "@/components/quick-actions"
import { RecentActivity } from "@/components/recent-activity"

export default function Dashboard() {
  return (
    <>
      <AppSidebar />
      <SidebarInset>
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
          <DashboardHeader />
          <div className="flex flex-1 flex-col gap-6 p-6">
            <DashboardStats />
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              <div className="xl:col-span-2 space-y-6">
                <LiveCallMonitor />
                <RecentActivity />
              </div>
              <div className="space-y-6">
                <AIPerformance />
                <QuickActions />
              </div>
            </div>
          </div>
        </div>
      </SidebarInset>
    </>
  )
}
