import { POCSidebar } from "@/components/poc-sidebar"
import { SidebarInset } from "@/components/ui/sidebar"
import { POCHeader } from "@/components/poc-header"
import { POCStats } from "@/components/poc-stats"
import { TrialProgress } from "@/components/trial-progress"
import { POCFeatures } from "@/components/poc-features"
import { POCSupport } from "@/components/poc-support"

export default function POCDashboard() {
  return (
    <>
      <POCSidebar />
      <SidebarInset>
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900">
          <POCHeader />
          <div className="flex flex-1 flex-col gap-6 p-6">
            <TrialProgress />
            <POCStats />
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              <div className="xl:col-span-2">
                <POCFeatures />
              </div>
              <div>
                <POCSupport />
              </div>
            </div>
          </div>
        </div>
      </SidebarInset>
    </>
  )
}
