import { AppSidebar } from "@/components/app-sidebar"
import { SidebarInset, SidebarTrigger } from "@/components/ui/sidebar"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Megaphone, Plus, TrendingUp, Users, Mail, MessageSquare } from "lucide-react"

export default function CampaignsPage() {
  return (
    <>
      <AppSidebar />
      <SidebarInset>
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          <SidebarTrigger className="-ml-1" />
          <div className="flex items-center gap-2">
            <Megaphone className="h-5 w-5" />
            <h1 className="text-lg font-semibold">Re-engagement Campaigns</h1>
          </div>
          <div className="ml-auto">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              New Campaign
            </Button>
          </div>
        </header>
        <div className="flex flex-1 flex-col gap-4 p-4">
          <div className="grid gap-4 md:grid-cols-3">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Campaigns</CardTitle>
                <TrendingUp className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">12</div>
                <p className="text-xs text-muted-foreground">+3 this month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Reach</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">8,547</div>
                <p className="text-xs text-muted-foreground">Contacts reached</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Engagement Rate</CardTitle>
                <MessageSquare className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">24.8%</div>
                <p className="text-xs text-muted-foreground">+5.2% improvement</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Campaign Performance</CardTitle>
              <CardDescription>AI-powered re-engagement campaigns</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-4">
                    <Mail className="h-8 w-8 text-blue-500" />
                    <div>
                      <h3 className="font-medium">Inactive Lead Revival</h3>
                      <p className="text-sm text-muted-foreground">Email sequence for 90-day inactive leads</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="secondary">Active</Badge>
                    <p className="text-sm text-muted-foreground mt-1">1,247 contacts</p>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-4">
                    <MessageSquare className="h-8 w-8 text-green-500" />
                    <div>
                      <h3 className="font-medium">SMS Follow-up</h3>
                      <p className="text-sm text-muted-foreground">Personalized SMS for missed calls</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="secondary">Active</Badge>
                    <p className="text-sm text-muted-foreground mt-1">892 contacts</p>
                  </div>
                </div>
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-4">
                    <TrendingUp className="h-8 w-8 text-purple-500" />
                    <div>
                      <h3 className="font-medium">Win-back Offer</h3>
                      <p className="text-sm text-muted-foreground">Special offers for churned customers</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="outline">Paused</Badge>
                    <p className="text-sm text-muted-foreground mt-1">456 contacts</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </SidebarInset>
    </>
  )
}
