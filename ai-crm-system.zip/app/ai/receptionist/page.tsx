import { AppSidebar } from "@/components/app-sidebar"
import { SidebarInset } from "@/components/ui/sidebar"
import { DashboardHeader } from "@/components/dashboard-header"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { HeadphonesIcon, Phone, Clock, CheckCircle, AlertCircle, Settings, Mic, Volume2 } from "lucide-react"

export default function AIReceptionistPage() {
  return (
    <>
      <AppSidebar />
      <SidebarInset>
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
          <DashboardHeader />
          <div className="flex flex-1 flex-col gap-6 p-6">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-2xl font-bold text-white flex items-center gap-3">
                  <HeadphonesIcon className="h-8 w-8 text-purple-400" />
                  AI Receptionist
                </h1>
                <p className="text-slate-400">Intelligent call handling and customer service automation</p>
              </div>
              <Badge variant="secondary" className="bg-green-500/20 text-green-300 border-green-400/30">
                <div className="w-2 h-2 bg-green-400 rounded-full mr-2 animate-pulse" />
                Active & Learning
              </Badge>
            </div>

            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-slate-300">Calls Today</CardTitle>
                  <Phone className="h-4 w-4 text-blue-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">247</div>
                  <p className="text-xs text-green-400">+18% from yesterday</p>
                </CardContent>
              </Card>
              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-slate-300">Avg Response</CardTitle>
                  <Clock className="h-4 w-4 text-purple-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">1.2s</div>
                  <p className="text-xs text-green-400">-0.3s improvement</p>
                </CardContent>
              </Card>
              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-slate-300">Resolution Rate</CardTitle>
                  <CheckCircle className="h-4 w-4 text-green-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">94%</div>
                  <p className="text-xs text-green-400">+3% this week</p>
                </CardContent>
              </Card>
              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium text-slate-300">Escalations</CardTitle>
                  <AlertCircle className="h-4 w-4 text-orange-400" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-white">12</div>
                  <p className="text-xs text-red-400">-5 from yesterday</p>
                </CardContent>
              </Card>
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Settings className="h-5 w-5 text-purple-400" />
                    AI Configuration
                  </CardTitle>
                  <CardDescription className="text-slate-400">Customize AI behavior and responses</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium text-slate-300">AI Voice Assistant</label>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium text-slate-300">Auto Call Recording</label>
                      <Switch defaultChecked />
                    </div>
                    <div className="flex items-center justify-between">
                      <label className="text-sm font-medium text-slate-300">Smart Call Routing</label>
                      <Switch defaultChecked />
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-sm font-medium text-slate-300">Response Style</label>
                    <select className="w-full p-3 bg-slate-900/50 border border-slate-700 rounded-lg text-slate-200 focus:border-purple-400 focus:outline-none">
                      <option value="professional">Professional</option>
                      <option value="friendly">Friendly</option>
                      <option value="casual">Casual</option>
                      <option value="formal">Formal</option>
                    </select>
                  </div>

                  <div className="space-y-3">
                    <label className="text-sm font-medium text-slate-300">Escalation Sensitivity</label>
                    <Slider defaultValue={[3]} max={7} min={1} step={1} className="w-full" />
                    <div className="flex justify-between text-xs text-slate-400">
                      <span>Low (1 attempt)</span>
                      <span>High (7 attempts)</span>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="text-sm font-medium text-slate-300">Voice Settings</label>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="space-y-2">
                        <label className="text-xs text-slate-400">Speed</label>
                        <Slider defaultValue={[50]} max={100} min={0} step={10} />
                      </div>
                      <div className="space-y-2">
                        <label className="text-xs text-slate-400">Pitch</label>
                        <Slider defaultValue={[50]} max={100} min={0} step={10} />
                      </div>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                    Save Configuration
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-slate-800/50 border-slate-700 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-white flex items-center gap-2">
                    <Mic className="h-5 w-5 text-green-400" />
                    Voice Training
                  </CardTitle>
                  <CardDescription className="text-slate-400">Test and improve AI voice responses</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
                      <h4 className="text-sm font-medium text-white mb-2">Sample Greeting</h4>
                      <p className="text-sm text-slate-300 italic">
                        "Hello! Thank you for calling Rosie AI. I'm your AI assistant. How can I help you today?"
                      </p>
                      <div className="flex items-center gap-2 mt-3">
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-slate-600 bg-slate-800 hover:bg-green-500/20"
                        >
                          <Volume2 className="h-4 w-4 mr-1" />
                          Play
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-slate-600 bg-slate-800 hover:bg-blue-500/20"
                        >
                          Edit
                        </Button>
                      </div>
                    </div>

                    <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
                      <h4 className="text-sm font-medium text-white mb-2">Escalation Message</h4>
                      <p className="text-sm text-slate-300 italic">
                        "I understand this is important to you. Let me connect you with one of our specialists who can
                        better assist you."
                      </p>
                      <div className="flex items-center gap-2 mt-3">
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-slate-600 bg-slate-800 hover:bg-green-500/20"
                        >
                          <Volume2 className="h-4 w-4 mr-1" />
                          Play
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-slate-600 bg-slate-800 hover:bg-blue-500/20"
                        >
                          Edit
                        </Button>
                      </div>
                    </div>

                    <div className="p-4 bg-slate-900/50 rounded-lg border border-slate-700">
                      <h4 className="text-sm font-medium text-white mb-2">Appointment Booking</h4>
                      <p className="text-sm text-slate-300 italic">
                        "I'd be happy to schedule that appointment for you. What day and time works best?"
                      </p>
                      <div className="flex items-center gap-2 mt-3">
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-slate-600 bg-slate-800 hover:bg-green-500/20"
                        >
                          <Volume2 className="h-4 w-4 mr-1" />
                          Play
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-slate-600 bg-slate-800 hover:bg-blue-500/20"
                        >
                          Edit
                        </Button>
                      </div>
                    </div>
                  </div>

                  <Button variant="outline" className="w-full border-purple-400 text-purple-300 hover:bg-purple-500/20">
                    <Mic className="mr-2 h-4 w-4" />
                    Record New Response
                  </Button>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </SidebarInset>
    </>
  )
}
