import { AdminSidebar } from "@/components/admin-sidebar"
import { SidebarInset } from "@/components/ui/sidebar"
import { AdminHeader } from "@/components/admin-header"
import { AdminStats } from "@/components/admin-stats"
import { SystemHealth } from "@/components/system-health"
import { RecentActivity } from "@/components/admin-activity"
import { UserManagement } from "@/components/user-management"

export default function AdminDashboard() {
  return (
    <>
      <AdminSidebar />
      <SidebarInset>
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-orange-900 to-slate-900">
          <AdminHeader />
          <div className="flex flex-1 flex-col gap-6 p-6">
            <AdminStats />
            <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
              <div className="xl:col-span-2 space-y-6">
                <SystemHealth />
                <RecentActivity />
              </div>
              <div className="space-y-6">
                <UserManagement />
              </div>
            </div>
          </div>
        </div>
      </SidebarInset>
    </>
  )
}
